<!-- Modal borrarcuenta-->
<div class="modal fade" id="borrarcuenta" tabindex="-1" role="dialog" aria-labelledby="borrarcuenta"
  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered    modal-lg" role="document">
    <div class="modal-content ">
      
      <div class="modal-body ">
        <div class="p-3">
          <div class="row d-flex justify-content-center">
            <div class="col-4">
              <img src="img/Icon awesome-exclamation-triangle.svg" class="w-100" alt="">
            </div>
            <p class="font-weight-bold text-center f12 my-2 ">¿Estás seguro que quieres eliminar tu cuenta y todos los anuncios que contiene?</p>
            <p class="font-weight-normal mt-2 f4">Ingresa tu contraseña para verificar que seas tu quien confirme la acción de Eliminar esta cuenta.</p>
              <input class="form-control campo1 w-100  f3" type="password" id="contraseñaactualmovil" name="contraseñaactualmovil" placeholder="Contraseña">
              <p class="color6 text-left f5 my-2">*Debes ingresar tu contraseña para eliminar esta cuenta.</p>
              <div class="row mt-3">
            <div class=" col-6 px-0">
              <a href="#" class="btn botonborrar  px-0" style="font-size: 10px;width: 150px;height: 43px;">Regresar</a>
            </div>
            <div class=" col-6 px-0">
              <a href="#" class="btn botonborrar1  px-0" style="font-size: 10px;width: 150px;height: 43px;">Borrar</a>
            </div>
          </div>
          </div>
        </div>
     
    </div>
  </div>
</div>

</div>

