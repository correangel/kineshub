<!-- Modal registro pc -->
<div class="modal fade" id="Registro" tabindex="-1" role="dialog" aria-labelledby="Registro"
  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered    modal-lg" style="max-width: 800px;" role="document">
    <div class="modal-content ">
       <div class="text-left mr-5">
         <button type="button" class="close cerrar1" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body ">
        <div class="row d-flex justify-content-center">
          <div class="col-10">
            <div class="text-center">
       <img src="img/logo.png" width="237" alt="">
       <p class="font-weight-bold mt-3 f2">Crea tu cuenta</p>
       <p class="font-weight-normal f4">Registrate ahora, solo dinos: ¿Quén eres?</p>
     </div>
     <div class="row d-flex justify-content-center">
       <div class="col-lg-8 col-12 text-center">
         <button class="btn boton13 w-100 f12"  data-toggle="modal" data-target="#reg_usuario" data-dismiss="modal" style="text-transform: capitalize;">Soy Usuario</button>
       </div>
      <div class="col-lg-8 col-12">
         <p class="text-center my-1">ó</p>
      </div>
       <div class="col-lg-8 col-12 text-center">
         <button class="btn boton14 w-100" data-toggle="modal" data-target="#registrok" data-dismiss="modal" >Soy una Kinesióloga</button>
       </div>
     </div>
   
    <div class="my-5">
      <p class=" font-weight-bolder text-center  f1">¿Ya tienes una cuenta? <a  data-toggle="modal" data-target="#sesion" data-dismiss="modal" class=" color2 font-weight-bold ml-1">Inicia Sesión</a></p>
          </div>
        </div>

     
      </div>
     
    </div>
  </div>
</div>

</div>

