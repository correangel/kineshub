<div class="fixed-bottom" style="right: 0px;">
	<div class="row justify-content-lg-start">
	<div class="col-lg-4 col-10"><div class="alert  alert-dismissible fade show " role="alert" style="padding-left: 40px;max-width: 300px">




 <div class="view">
    <img src="img/Trazado 81.svg" class="img-fluid" width="" alt="">
    <div class="mask flex-center">
        <h2 class="f10 font-weight-bolder text-white f16" style="position: absolute;top: 30px; right: 32px;">03:59</h2>
        <div class="flex-center ml-4" style="position: relative;top: 35px;">
        	<p class="text-white f4">¡Regístrate y accede a un sorteo <br> para <u><a href="#" class="text-white">UNA NOCHE GRATIS</a></u> con <br> nuestras kines!</p>
        </div>
        
    </div>
</div>

  <button type="button" class="close cerrar3" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true" class="" style="    position: absolute;
    top: 10px;
    right: 13px;">&times;</span>
  </button>
</div></div>
</div>
</div>

