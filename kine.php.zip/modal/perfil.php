<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
<script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
<!-- Modal perfil -->
<div class="modal fade" id="perfilkine" tabindex="-1" role="dialog" aria-labelledby="perfilkine"
  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered  modal-lg" role="document">
    <div class="modal-content">
      <div class="d-block d-md-none">
         <div class="text-left mr-5 ">
         <button type="button" class="close cerrar2" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
           <img src="img/Rectangle 3.png" class="card-img-top" alt="">
      </div>
       <div class="text-left mr-5 d-none d-md-block">
         <button type="button" class="close cerrar1" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <div class="container">
         <div class="row">
           <div class="col-lg-4 d-none d-md-block">
             <img src="img/Rectangle 3.png" class="card-img-top" alt="">

      
         
               <div class="d-none d-md-block">
                  <div class="row mt-2 ">
              <div class="col-lg-4 col-12 pr-md-0">
                <a href="" class="btn boton18 w-100"><img src="img/Icon ionic-ios-call.svg" width="15" alt="">  Llamar</a>
              </div>
               <div class="col-lg-4 col-12 ">
                <div class="text-center  pl-md-0">
                  <a href="" class="btn w-100 boton17"><img src="img/Icon ionic-logo-whatsapp.svg" width="15" alt=""></a>
                </div>
                
              </div>
              <div class="col-lg-4 col-12  pl-md-0">
                <div class="text-center">
                  <a href="" class="btn w-100 boton16"><i class="fas fa-heart "></i> Favoritos</a>
                </div>
                
              </div>
            </div>
               </div>
           
             <div class="row mt-2">
               <div class="col-lg-12 col-12">
                 <button class="btn boton15 w-100">Verificar foto</button>
               </div>
                <div class="col-lg-12 col-12">
                 <button class="btn boton14 w-100">Panel de kine</button>
               </div>
             </div>
           </div>




           <div class="col-lg-8">
            <div class="d-none d-md-block">
              <!-- titulo version pc  -->
               <h2 class="font-weight-bold mt-5 mt-md-0">Isabella 123456, Lorem ipsum dolor sit amet, consetetur</h2>
            </div>
            <!-- titulo version movil  -->
            <div class="d-block d-md-none ">
              <h2 class="font-weight-bolder mt-5 mt-md-0">Isabella  <img src="img/Grupo 163.svg" class="ml-2" width="17" height="24" alt=""><img src="img/Grupo 206.svg" class="ml-1" width="84" height="21" alt=""></h2>
              
            </div>
            
              <span class="badge badge-pill badge-light">Lima Metropolitana</span>
          <span class="badge badge-pill badge-light">18 años</span>
          <span class="badge badge-pill badge-light">S/180</span>
          <span class="badge badge-pill badge-light">Venezolana</span>
          <p class="color4 f3 ml-2 mt-3"><i class="fas fa-redo-alt"></i> 13/12/2020 2:00pm</p>
          <p class="f9 font-weight-normal text-justify">Lorem, ipsum dolor sit amet, consectetur adipisicing elit. Nemo laborum ea impedit molestiae, architecto reiciendis, harum dolorum rerum ut deserunt, minima dolor distinctio repellendus ullam, commodi consectetur debitis minus quibusdam fugiat animi ad. Maxime, asperiores ipsa impedit laboriosam autem repellendus sapiente deleniti ex sequi at mollitia ea placeat cum molestias.</p>
           <p class="f9 font-weight-normal text-justify">Lorem, ipsum dolor sit amet, consectetur adipisicing elit. Nemo laborum ea impedit molestiae, architecto reiciendis, harum dolorum rerum ut deserunt, minima dolor distinctio repellendus ullam, commodi consectetur debitis minus quibusdam fugiat animi ad. Maxime, asperiores ipsa impedit laboriosam autem repellendus sapiente deleniti ex sequi at mollitia ea placeat cum molestias.</p>
           <hr class="my-5">
           <div class="row d-flex align-items-start">
             <div class="col-lg-6 col-12 ">
              <div class="d-flex">
                  <img src="img/Icon awesome-clock.svg" alt=""> <span class="f9 font-weight-normal pl-2">Horario</span>
              </div>
            <table class="table mt-4">
  <thead class="fondocolor1 text-center">
    <tr>
      <th scope="col" class="dias">Dias</th>
      <th scope="col" class="horas">Horas</th>
      
    </tr>
  </thead>
  <tbody class="table-bordered text-center text-md-left">
    <tr>
      <th scope="row">Lunes</th>
      <td class="text-center fondocolor2">8:00am a 12:00pm</td>
     
    </tr>
    <tr>
      <th scope="row">Martes</th>
      <td class="text-center fondocolor2">3:00pm a 10:00pm</td>
      
    </tr>
    <tr>
      <th scope="row">Miercoles a viernes</th>
      <td  class="text-center fondocolor2">5:00pm a 9:00pm</td>
      
    </tr>
    <tr>
      <th scope="row">Sabado y domingo</th>
      <td  class="text-center fondocolor2">8:00am a 10:00pm</td>
      
    </tr>
  </tbody>
</table>
               <div>
                 
               </div>
             </div>
             <div class="col-lg-6 col-12 ">
              <div class="d-flex">
                 <img src="img/Icon material-monetization-on.svg" alt=""> <span class="f9  font-weight-normal pl-2">Tarifas</span>
              </div>
               <table class="table mt-4">
  <thead class="fondocolor1 text-center">
    <tr>
      <th scope="col" class="dias">Tiempo</th>
      <th scope="col" class="horas">Costo</th>
      
    </tr>
  </thead>
  <tbody class="table-bordered">
    <tr>
      <th scope="row" class="pl-0 text-center pl-md-3">1 hora</th>
      <td class="text-center fondocolor2">S/150</td>
     
    </tr>
    <tr>
      <th scope="row" class="pl-0 text-center pl-md-3">30 min</th>
      <td class="text-center fondocolor2">S/80</td>
      
    </tr>
    <tr>
      <th scope="row" class="pl-0 text-center pl-md-3">20 min</th>
      <td  class="text-center fondocolor2">S/60</td>
      
    </tr>

  </tbody>
</table>
                 
             </div>
           </div>
           <hr class="my-5">
           <p class="f9  font-weight-normal ">Mi galeria</p>
           <div class="row ">
             <div class="col-lg-6 col-12 pr-2 pr-md-1 ">
              <a data-fancybox="gallery" href="img/1607530711.jpg"> <img src="img/Rectangle 3.png" class="imagen1x mt-2" alt=""></a>
                 
         
              <a data-fancybox="gallery" href="img/Rectangle 3.png"> <img src="img/Rectangle 3.png" class="w-100 mt-2" alt=""></a>
               
             </div>
             <div class="col-lg-6 col-12 pl-2 pl-md-1">
               <a data-fancybox="gallery" href="img/1607530711.jpg"> <img src="img/Rectangle 3.png" class="imagen2x mt-2" alt=""></a>
                    <a data-fancybox="gallery" href="img/1607530711.jpg"> <img src="img/Rectangle 3.png" class="w-100 mt-2" alt=""></a>
             </div>
            
           </div>
              <hr class="my-5">
                <p class="f9  font-weight-normal ">Sobre mi</p>
              <div>
                 <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem</span>
               <span class="badge badge-pill badge-light">25 años</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
              </div>
              <hr class="my-5">
                 <p class="f9  font-weight-normal ">Mis servicios</p>
              <div>
                 <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem</span>
              <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
              </div>
               <hr class="my-5">
               <p class="f9  font-weight-normal ">Mis servicios especiales</p>
              <div>
                 <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem</span>
              <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem ipsum.</span>
              </div>
               <hr class="my-5">
                 
               <p class="f9  font-weight-normal ">Lugar de encuentro</p>
              <div>
                 <span class="badge badge-pill badge-light">Lorem ipsum.</span>
               <span class="badge badge-pill badge-light">Lorem</span>
           
              </div>
              <hr class="my-5">
                <div class="d-flex">
                 <img src="img/Icon ionic-md-alert.svg" alt=""> <span class="f9  font-weight-normal pl-2"> Denunciar anuncio</span>
              </div>
              <p class="f2 font-weight-normal mt-2">Infórmanos sobre posibles incidencias en el anuncio de esta kinesiologa</p>
              <div class="row mb-5">
                <div class="col-lg-6 col-12">
                  <button class="btn boton14 w-100">Mostrar formulario</button>
                </div>
                
              </div>
<div class=" text-center mt-5  d-block d-md-none">
      <p class="grey-text f3">@Kineshub 2020. <br> Todos los derechos reservados.</p>
    </div>

           </div>
         </div>
       </div>
      </div>
      <div class="modal-footer py-0 my-0 d-block d-md-none">
      
            <div class="row pr-2">
          <div class="col px-0 mx-0">
            <button class="btn boton18 w-100 waves-effect waves-light" style="
    font-size: 10px;
"><img src="img/Icon ionic-ios-call.svg" width="15" alt="">  Llamar</button>
          </div>
          <div class="col px-2 mx-0">
            <button class="boton17 w-100 btn waves-effect waves-light"><img src="img/Icon ionic-logo-whatsapp.svg" width="15" alt=""></button>
          </div>
          <div class="col px-0 mx-0">
            <button class="btn  w-100 boton16 waves-effect waves-light" style="
    height: 46px;
    font-size: 10px;
"><i class="fas fa-heart "></i> Favoritos</button>
          </div>
        </div>
      </div>
     
    </div>
  </div>
</div>


