<!-- Modal eliminaranuncio-->
<div class="modal fade" id="eliminaranuncio" tabindex="-1" role="dialog" aria-labelledby="eliminaranuncio"
  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered    " role="document">
    <div class="modal-content ">
      
      <div class="modal-body ">
        <div class="p-3">
      
          <div class="row d-flex justify-content-center">
            <div class="col-lg-4">
              <img src="img/Icon awesome-exclamation-triangle.svg" class="w-100" alt="">
            </div>
              <p class="font-weight-bold text-center f12 my-3 ">¿Estás seguro que quieres eliminar tu anuncio?</p>
               <div class="row mt-3">
            <div class=" col-6 px-0">
              <a href="#" class="btn botonborrar  px-0" style="font-size: 10px;width: 150px;height: 43px;">Regresar</a>
            </div>
            <div class=" col-6 px-0">
              <a onclick="eliminar_anuncio()" class="btn botonborrar1  px-0" style="font-size: 10px;width: 150px;height: 43px;">Borrar</a>
            </div>
          </div>
          </div>
         
        </div>
     
    </div>
  </div>
</div>

</div>

