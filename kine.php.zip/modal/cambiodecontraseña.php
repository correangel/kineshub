<!-- Modal cambiocontraseña-->
<div class="modal fade" id="cambiocontraseña" tabindex="-1" role="dialog" aria-labelledby="cambiocontraseña"
  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered    modal-lg" role="document">
    <div class="modal-content ">
      
      <div class="modal-body ">
        <div class="p-3">
          <div class="row d-flex justify-content-center ">
            <div class="col-12">
              <div class="row d-flex justify-content-center">
                <div class="col-4">
                   <img src="img/Icon ionic-ios-lock.svg" class="w-100" alt="">
                </div>
              </div>

             
            </div>
            <div class="text-left">
              <div class="mb-2">
                  <p class="font-weight-bold text-center f12 my-2  ">Cambia tu contraseña</p>
            <p class="font-weight-normal mt-3 mb-2 f4">Ingresa tu contraseña actual</p>
              <input class="form-control campo1 w-100  f3" type="password" id="contraseñaactualmovil" name="contraseñaactualmovil" placeholder="Contraseña">
              <p class="color6 text-left f5 my-2">*Debes ingresar tu contraseña para eliminar esta cuenta.</p>
              </div>
              <div>
                 <p class="font-weight-normal mt-3 mb-2 f4">Ingresa y confirma tu nueva contraseña</p>
                   <input class="form-control campo1 w-100  f3" type="password" id="contraseñanuevamovil" name="contraseñanuevamovil" placeholder="Nueva contraseña">
                     <input class="form-control campo1 mt-2 w-100  f3" type="password" id="repitacontraseñanuevamovil" name="repitacontraseñanuevamovil" placeholder="Confirmar contraseña">
                      <p class="color6 text-left f5 my-2">*Debes ingresar tu NUEVA contraseña en AMBOS recuadros.</p>
              </div>
              

            </div>
          








              <div class="row mt-3 d-flex">
            <div class=" col-6 px-0">
              <a href="#" class="btn botonborrar  px-0" style="font-size: 10px;width: 150px;height: 43px;">Regresar</a>
            </div>
            <div class=" col-6 px-0">
              <a href="#" class="btn botonborrar1  px-0" style="font-size: 10px;width: 150px;height: 43px;">Cambiar contraseña</a>
            </div>
          </div>
          </div>
        </div>  
     
    </div>
  </div>
</div>

</div>

