<!-- Modal foto verificada-->
<div class="modal fade" id="verificarfoto" tabindex="-1" role="dialog" aria-labelledby="verificarfoto1"
  aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered  " role="document">
    <div class="modal-content">
       <div class="text-left mr-5">
         <button type="button" class="close cerrar1" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div>
        <img src="img/Grupo 415.png" class="w-100" alt="">
      </div>
     
     
    </div>
  </div>
</div>